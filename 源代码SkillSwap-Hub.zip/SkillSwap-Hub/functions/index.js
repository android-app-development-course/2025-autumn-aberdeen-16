const functions = require('firebase-functions');

// 模拟附近用户数据库
const MOCK_DB = [
    { name: "张三", skill: "英语口语", lat: 31.23, lng: 121.47 },
    { name: "王五", skill: "摄影制作", lat: 31.24, lng: 121.48 }
];

exports.getNearbyUsers = functions.https.onRequest((req, res) => {
    // 允许跨域（重要：防止前端调用报错）
    res.set('Access-Control-Allow-Origin', '*');
    
    const userLat = parseFloat(req.query.lat);
    const userLng = parseFloat(req.query.lng);

    if (isNaN(userLat) || isNaN(userLng)) {
        return res.status(400).send({error: "需要经纬度"});
    }

    // 简易距离排序逻辑
    const results = MOCK_DB.map(user => {
        const d = Math.sqrt(Math.pow(user.lat - userLat, 2) + Math.pow(user.lng - userLng, 2)) * 111; 
        return { ...user, d: d.toFixed(2) };
    }).sort((a, b) => a.d - b.d);

    res.status(200).send(results);
});